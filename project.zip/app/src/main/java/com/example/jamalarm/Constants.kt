package com.example.jamalarm

const val EXTRA_ID = "alarm_id"
const val EXTRA_SNOOZE = "is_snooze"
const val ACTION_STOP = "com.example.jamalarm.STOP"
const val ACTION_SNOOZE = "com.example.jamalarm.SNOOZE"
const val ACTION_DISMISSED = "com.example.jamalarm.DISMISSED"
