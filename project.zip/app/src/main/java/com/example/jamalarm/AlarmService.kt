package com.example.jamalarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class AlarmService : Service() {

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())
    private var volume = 1f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getIntExtra(EXTRA_ID, -1) ?: -1
        val alarm = AlarmStore.load(this).firstOrNull { it.id == id }

        when (intent?.action) {
            ACTION_STOP -> {
                shutdown()
                return START_NOT_STICKY
            }
            ACTION_SNOOZE -> {
                if (alarm != null && alarm.snoozeMinutes > 0) {
                    AlarmScheduler.scheduleSnooze(
                        this, alarm.id, System.currentTimeMillis() + alarm.snoozeMinutes * 60_000L
                    )
                }
                shutdown()
                return START_NOT_STICKY
            }
        }

        // Wajib memanggil startForeground secepatnya setelah startForegroundService
        ServiceCompat.startForeground(
            this, NOTIF_ID, buildNotification(alarm, id),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
        )
        if (alarm == null) {
            shutdown()
            return START_NOT_STICKY
        }
        startSound(alarm)
        return START_NOT_STICKY
    }

    private fun buildNotification(alarm: Alarm?, id: Int): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Alarm", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                enableVibration(false)
            }
        )
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val ring = PendingIntent.getActivity(
            this, id,
            Intent(this, RingActivity::class.java)
                .putExtra(EXTRA_ID, id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            flags
        )
        fun action(a: String, code: Int) = PendingIntent.getService(
            this, id * 10 + code,
            Intent(this, AlarmService::class.java).setAction(a).putExtra(EXTRA_ID, id),
            flags
        )
        val time = alarm?.let { "%02d:%02d".format(it.hour, it.minute) } ?: ""
        val builder = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(alarm?.label?.ifBlank { "Alarm" } ?: "Alarm")
            .setContentText(time)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .setContentIntent(ring)
            .setFullScreenIntent(ring, true)
        if (alarm != null && alarm.snoozeMinutes > 0 && !alarm.math) {
            builder.addAction(0, "Tunda ${alarm.snoozeMinutes} menit", action(ACTION_SNOOZE, 1))
        }
        // Alarm dengan soal hitung hanya bisa dimatikan dari layar alarm
        if (alarm == null || !alarm.math) builder.addAction(0, "Matikan", action(ACTION_STOP, 2))
        return builder.build()
    }

    private fun startSound(alarm: Alarm) {
        stopSound()
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        volume = if (alarm.gradual) 0.1f else 1f
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AlarmService, uri)
                isLooping = true
                prepare()
                setVolume(volume, volume)
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        if (alarm.gradual) {
            handler.postDelayed(object : Runnable {
                override fun run() {
                    volume = (volume + 0.03f).coerceAtMost(1f)
                    player?.setVolume(volume, volume)
                    if (volume < 1f) handler.postDelayed(this, 1000)
                }
            }, 1000)
        }
        @Suppress("DEPRECATION")
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 600), 0))
        // Berhenti otomatis setelah 10 menit
        handler.postDelayed({ shutdown() }, 10 * 60 * 1000L)
    }

    private fun stopSound() {
        handler.removeCallbacksAndMessages(null)
        try {
            player?.stop()
        } catch (e: Exception) {
        }
        player?.release()
        player = null
        vibrator?.cancel()
    }

    private fun shutdown() {
        stopSound()
        stopForeground(STOP_FOREGROUND_REMOVE)
        sendBroadcast(Intent(ACTION_DISMISSED).setPackage(packageName))
        stopSelf()
    }

    override fun onDestroy() {
        stopSound()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "alarm_channel"
        private const val NOTIF_ID = 1001
    }
}
