package com.example.jamalarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** days memakai konstanta Calendar (SUNDAY=1 .. SATURDAY=7). Kosong = sekali saja. */
data class Alarm(
    val id: Int = 0,
    val hour: Int,
    val minute: Int,
    val label: String = "",
    val days: Set<Int> = emptySet(),
    val enabled: Boolean = true,
    val snoozeMinutes: Int = 5,
    val gradual: Boolean = true,
    val math: Boolean = false,
)

/** Waktu bunyi berikutnya (ms), atau -1 kalau tidak ada. */
fun Alarm.nextTrigger(from: Long = System.currentTimeMillis()): Long {
    val cal = Calendar.getInstance()
    for (i in 0..7) {
        cal.timeInMillis = from
        cal.add(Calendar.DAY_OF_YEAR, i)
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        if (cal.timeInMillis <= from) continue
        if (days.isEmpty() || cal.get(Calendar.DAY_OF_WEEK) in days) return cal.timeInMillis
    }
    return -1L
}

fun daysText(days: Set<Int>): String {
    if (days.isEmpty()) return "Sekali"
    if (days.size == 7) return "Setiap hari"
    val weekdays = setOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY)
    if (days == weekdays) return "Senin–Jumat"
    if (days == setOf(Calendar.SATURDAY, Calendar.SUNDAY)) return "Akhir pekan"
    val names = mapOf(
        Calendar.MONDAY to "Sen", Calendar.TUESDAY to "Sel", Calendar.WEDNESDAY to "Rab",
        Calendar.THURSDAY to "Kam", Calendar.FRIDAY to "Jum", Calendar.SATURDAY to "Sab", Calendar.SUNDAY to "Min",
    )
    return names.filterKeys { it in days }.values.joinToString(", ")
}

fun durText(ms: Long): String {
    val mins = ((ms + 59_999) / 60_000).toInt()
    if (mins < 1) return "kurang dari 1 menit"
    val h = mins / 60
    val m = mins % 60
    val d = h / 24
    return when {
        d > 0 -> "$d hari ${h % 24} jam"
        h > 0 -> "$h jam $m menit"
        else -> "$m menit"
    }
}

object AlarmStore {
    private const val PREFS = "alarms"
    private const val KEY = "list"

    fun load(ctx: Context): List<Alarm> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                val d = o.getJSONArray("days")
                Alarm(
                    id = o.getInt("id"),
                    hour = o.getInt("hour"),
                    minute = o.getInt("minute"),
                    label = o.optString("label", ""),
                    days = (0 until d.length()).map { d.getInt(it) }.toSet(),
                    enabled = o.optBoolean("enabled", true),
                    snoozeMinutes = o.optInt("snooze", 5),
                    gradual = o.optBoolean("gradual", true),
                    math = o.optBoolean("math", false),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Alarm>) {
        val arr = JSONArray()
        list.forEach { a ->
            arr.put(JSONObject().apply {
                put("id", a.id)
                put("hour", a.hour)
                put("minute", a.minute)
                put("label", a.label)
                put("days", JSONArray(a.days.toList()))
                put("enabled", a.enabled)
                put("snooze", a.snoozeMinutes)
                put("gradual", a.gradual)
                put("math", a.math)
            })
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }
}
