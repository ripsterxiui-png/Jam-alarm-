@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.example.jamalarm

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var reloadKey by mutableStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { AppTheme { AlarmApp(reloadKey) } }
    }

    override fun onResume() {
        super.onResume()
        reloadKey++ // muat ulang daftar alarm (mis. alarm sekali sudah mati sendiri)
    }
}

@Composable
fun AlarmApp(reloadKey: Int) {
    val ctx = LocalContext.current
    val alarms = remember { mutableStateListOf<Alarm>() }
    var dialogAlarm by remember { mutableStateOf<Alarm?>(null) }
    var showDialog by remember { mutableStateOf(false) }

    LaunchedEffect(reloadKey) {
        alarms.clear()
        alarms.addAll(AlarmStore.load(ctx))
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun upsert(a: Alarm) {
        val item = if (a.id == 0) a.copy(id = (alarms.maxOfOrNull { it.id } ?: 0) + 1) else a
        val i = alarms.indexOfFirst { it.id == item.id }
        if (i >= 0) alarms[i] = item else alarms.add(item)
        AlarmStore.save(ctx, alarms.toList())
        if (item.enabled) {
            AlarmScheduler.schedule(ctx, item)
            val at = item.nextTrigger()
            if (at > 0) Toast.makeText(ctx, "Berbunyi dalam ${durText(at - System.currentTimeMillis())}", Toast.LENGTH_SHORT).show()
        } else {
            AlarmScheduler.cancel(ctx, item.id)
        }
    }

    fun remove(a: Alarm) {
        alarms.removeAll { it.id == a.id }
        AlarmStore.save(ctx, alarms.toList())
        AlarmScheduler.cancel(ctx, a.id)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { dialogAlarm = null; showDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
            ) { Text("Tambah alarm", modifier = Modifier.padding(horizontal = 8.dp), fontWeight = FontWeight.Bold) }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.padding(padding).fillMaxSize(),
            contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 110.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item { ClockHeader(alarms) }
            if (alarms.isEmpty()) {
                item {
                    Text(
                        "Belum ada alarm. Ketuk Tambah alarm untuk membuat yang pertama.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            items(alarms.sortedBy { it.hour * 60 + it.minute }, key = { it.id }) { a ->
                AlarmCard(
                    a,
                    onClick = { dialogAlarm = a; showDialog = true },
                    onToggle = { on -> upsert(a.copy(enabled = on)) },
                )
            }
        }
    }

    if (showDialog) {
        AlarmDialog(
            initial = dialogAlarm,
            onSave = { upsert(it.copy(enabled = true)); showDialog = false },
            onDelete = if (dialogAlarm != null) ({ dialogAlarm?.let { remove(it) }; showDialog = false }) else null,
            onDismiss = { showDialog = false },
        )
    }
}

@Composable
fun ClockHeader(alarms: List<Alarm>) {
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val next = alarms.filter { it.enabled }.map { it.nextTrigger(now) }.filter { it > 0 }.minOrNull()
    Column(Modifier.fillMaxWidth().padding(vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now)),
            fontSize = 76.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            SimpleDateFormat("EEEE, d MMMM yyyy", Locale("id", "ID")).format(Date(now)),
            fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            if (next != null) "Alarm berikutnya berbunyi dalam ${durText(next - now)}" else "Belum ada alarm aktif",
            color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp,
        )
    }
}

@Composable
fun AlarmCard(a: Alarm, onClick: () -> Unit, onToggle: (Boolean) -> Unit) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).alpha(if (a.enabled) 1f else 0.45f)) {
                Text("%02d:%02d".format(a.hour, a.minute), fontSize = 40.sp, fontWeight = FontWeight.Light)
                Text(a.label.ifBlank { "Alarm" }, fontWeight = FontWeight.SemiBold)
                Text(
                    daysText(a.days) + if (a.math) ", soal hitung" else "",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp,
                )
            }
            Switch(checked = a.enabled, onCheckedChange = onToggle)
        }
    }
}

@Composable
fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun AlarmDialog(initial: Alarm?, onSave: (Alarm) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit) {
    val nextHour = remember { (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) + 1) % 24 }
    val state = rememberTimePickerState(
        initialHour = initial?.hour ?: nextHour,
        initialMinute = initial?.minute ?: 0,
        is24Hour = true,
    )
    var label by remember { mutableStateOf(initial?.label ?: "") }
    var days by remember { mutableStateOf(initial?.days ?: emptySet()) }
    var snooze by remember { mutableStateOf(initial?.snoozeMinutes ?: 5) }
    var gradual by remember { mutableStateOf(initial?.gradual ?: true) }
    var math by remember { mutableStateOf(initial?.math ?: false) }

    val dayOptions = listOf(
        Calendar.MONDAY to "Sen", Calendar.TUESDAY to "Sel", Calendar.WEDNESDAY to "Rab",
        Calendar.THURSDAY to "Kam", Calendar.FRIDAY to "Jum", Calendar.SATURDAY to "Sab", Calendar.SUNDAY to "Min",
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.padding(horizontal = 12.dp),
        properties = DialogProperties(usePlatformDefaultWidth = false),
        title = { Text(if (initial == null) "Alarm baru" else "Ubah alarm") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                TimePicker(state = state, modifier = Modifier.align(Alignment.CenterHorizontally))
                OutlinedTextField(
                    value = label, onValueChange = { label = it.take(40) },
                    label = { Text("Nama alarm") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                Text("Ulangi (kosongkan untuk sekali saja)", modifier = Modifier.padding(top = 14.dp, bottom = 6.dp), fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    dayOptions.forEach { (d, name) ->
                        FilterChip(
                            selected = d in days,
                            onClick = { days = if (d in days) days - d else days + d },
                            label = { Text(name) },
                        )
                    }
                }
                Text("Tunda", modifier = Modifier.padding(top = 14.dp, bottom = 6.dp), fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0, 5, 10, 15).forEach { m ->
                        FilterChip(
                            selected = snooze == m,
                            onClick = { snooze = m },
                            label = { Text(if (m == 0) "Tanpa tunda" else "$m menit") },
                        )
                    }
                }
                SwitchRow("Volume naik perlahan", "Dari pelan ke keras dalam 30 detik", gradual) { gradual = it }
                SwitchRow("Matikan dengan soal hitung", "Jawab soal dulu supaya benar-benar bangun", math) { math = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    Alarm(
                        id = initial?.id ?: 0,
                        hour = state.hour, minute = state.minute,
                        label = label.trim(), days = days,
                        snoozeMinutes = snooze, gradual = gradual, math = math,
                    )
                )
            }) { Text("Simpan") }
        },
        dismissButton = {
            Row {
                if (onDelete != null) {
                    TextButton(onClick = onDelete) { Text("Hapus", color = MaterialTheme.colorScheme.primary) }
                }
                TextButton(onClick = onDismiss) { Text("Batal") }
            }
        },
    )
}
