package com.example.jamalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Calendar
import kotlin.random.Random

class RingActivity : ComponentActivity() {

    private var registered = false
    private val dismissReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Tampil di atas layar kunci dan nyalakan layar
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val id = intent.getIntExtra(EXTRA_ID, -1)
        val alarm = AlarmStore.load(this).firstOrNull { it.id == id }
        if (alarm == null) {
            finish()
            return
        }

        ContextCompat.registerReceiver(
            this, dismissReceiver, IntentFilter(ACTION_DISMISSED), ContextCompat.RECEIVER_NOT_EXPORTED
        )
        registered = true

        fun send(action: String) {
            startService(Intent(this, AlarmService::class.java).setAction(action).putExtra(EXTRA_ID, id))
        }

        setContent {
            AppTheme {
                RingScreen(
                    alarm = alarm,
                    onSnooze = { send(ACTION_SNOOZE) },
                    onStop = { send(ACTION_STOP) },
                )
            }
        }
    }

    override fun onDestroy() {
        if (registered) unregisterReceiver(dismissReceiver)
        super.onDestroy()
    }
}

private data class MathQ(val text: String, val answer: Int)

private fun newQuestion(): MathQ {
    val a = Random.nextInt(12, 50)
    val b = Random.nextInt(3, 10)
    val c = Random.nextInt(2, 10)
    return MathQ("$a + $b × $c", a + b * c)
}

@Composable
private fun RingScreen(alarm: Alarm, onSnooze: () -> Unit, onStop: () -> Unit) {
    var q by remember { mutableStateOf(newQuestion()) }
    var answer by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    val now = remember { Calendar.getInstance() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .safeDrawingPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(
            "%02d:%02d".format(now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE)),
            fontSize = 84.sp, fontWeight = FontWeight.Light, color = MaterialTheme.colorScheme.onBackground,
        )
        Text(
            alarm.label.ifBlank { "Alarm" },
            fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary,
        )
        Spacer(Modifier.height(28.dp))

        if (alarm.math) {
            Text("${q.text} = ?", fontSize = 28.sp, color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = answer,
                onValueChange = { answer = it.filter { c -> c.isDigit() } },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                label = { Text("Jawaban") },
                modifier = Modifier.fillMaxWidth(),
            )
            if (wrong) {
                Text("Belum tepat, coba soal baru", color = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.height(20.dp))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            if (alarm.snoozeMinutes > 0) {
                OutlinedButton(onClick = onSnooze, modifier = Modifier.weight(1f).height(56.dp)) {
                    Text("Tunda ${alarm.snoozeMinutes} menit")
                }
            }
            Button(
                onClick = {
                    if (!alarm.math || answer.toIntOrNull() == q.answer) {
                        onStop()
                    } else {
                        wrong = true
                        q = newQuestion()
                        answer = ""
                    }
                },
                modifier = Modifier.weight(1f).height(56.dp),
            ) { Text("Matikan") }
        }
    }
}
