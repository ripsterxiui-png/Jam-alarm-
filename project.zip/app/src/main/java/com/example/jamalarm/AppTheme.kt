package com.example.jamalarm

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) {
        darkColorScheme(
            primary = Color(0xFFFF6E98), onPrimary = Color(0xFF1A0A12),
            secondary = Color(0xFF7FA8FF),
            background = Color(0xFF0F1330), onBackground = Color(0xFFEEF0FF),
            surface = Color(0xFF1A2050), onSurface = Color(0xFFEEF0FF),
            surfaceVariant = Color(0xFF252D66), onSurfaceVariant = Color(0xFFA2ABDC),
        )
    } else {
        lightColorScheme(
            primary = Color(0xFFE93B75), onPrimary = Color.White,
            secondary = Color(0xFF3E7BFA),
            background = Color(0xFFEEF1FB), onBackground = Color(0xFF171C3A),
            surface = Color.White, onSurface = Color(0xFF171C3A),
            surfaceVariant = Color(0xFFE4E9F9), onSurfaceVariant = Color(0xFF565E8C),
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
