package com.example.jamalarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object AlarmScheduler {

    private fun pending(ctx: Context, id: Int, snooze: Boolean): PendingIntent {
        val intent = Intent(ctx, AlarmReceiver::class.java)
            .putExtra(EXTRA_ID, id)
            .putExtra(EXTRA_SNOOZE, snooze)
        val code = if (snooze) id + 100_000 else id
        return PendingIntent.getBroadcast(
            ctx, code, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun showIntent(ctx: Context): PendingIntent =
        PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)

    private fun setAt(ctx: Context, at: Long, pi: PendingIntent) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        // setAlarmClock = alarm tepat waktu, tidak perlu izin khusus, tembus mode hemat daya (Doze)
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, showIntent(ctx)), pi)
    }

    fun schedule(ctx: Context, alarm: Alarm) {
        val at = alarm.nextTrigger()
        if (at > 0) setAt(ctx, at, pending(ctx, alarm.id, false))
    }

    fun scheduleSnooze(ctx: Context, id: Int, at: Long) {
        setAt(ctx, at, pending(ctx, id, true))
    }

    fun cancel(ctx: Context, id: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx, id, false))
        am.cancel(pending(ctx, id, true))
    }

    fun rescheduleAll(ctx: Context) {
        AlarmStore.load(ctx).filter { it.enabled }.forEach { schedule(ctx, it) }
    }
}
