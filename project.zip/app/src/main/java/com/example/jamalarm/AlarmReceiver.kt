package com.example.jamalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra(EXTRA_ID, -1)
        val isSnooze = intent.getBooleanExtra(EXTRA_SNOOZE, false)
        val list = AlarmStore.load(context)
        val alarm = list.firstOrNull { it.id == id } ?: return

        if (!isSnooze) {
            if (alarm.days.isEmpty()) {
                // Alarm sekali saja: matikan setelah bunyi
                AlarmStore.save(context, list.map { if (it.id == id) it.copy(enabled = false) else it })
            } else {
                // Alarm berulang: jadwalkan kemunculan berikutnya
                AlarmScheduler.schedule(context, alarm)
            }
        }

        ContextCompat.startForegroundService(
            context,
            Intent(context, AlarmService::class.java).putExtra(EXTRA_ID, id)
        )
    }
}
