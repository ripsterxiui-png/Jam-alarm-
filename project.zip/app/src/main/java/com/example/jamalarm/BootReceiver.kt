package com.example.jamalarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Menjadwalkan ulang semua alarm setelah HP restart atau aplikasi diperbarui. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        AlarmScheduler.rescheduleAll(context)
    }
}
